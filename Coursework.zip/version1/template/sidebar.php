    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Movies <sup>Rental</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Nav Item - Films Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Films Management</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Actor:</h6>
            <a class="collapse-item" href="actor_index.php">List all actor</a>
            <a class="collapse-item" href="actor_create.php">New actor</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Category:</h6>
            <a class="collapse-item" href="film_category_index.php">List all category</a>
            <a class="collapse-item" href="film_category_create.php">New film category</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Title and Description:</h6>
            <a class="collapse-item" href="film_text_index.php">List All</a>
            <a class="collapse-item" href="film_text_create.php">New Title & Description</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Films:</h6>
            <a class="collapse-item" href="film_add_index.php">List All film</a>
            <a class="collapse-item" href="film_add_create.php">New Film</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Inventory management -->
      <li class="nav-item">
        <a class="nav-link" href="inventory_index.php">
          <i class="fas fa-fw fa-warehouse"></i>
          <span>Inventory Management</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Rental management -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseRental" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-money-bill-wave"></i>
          <span>Rentals Management</span>
        </a>
        <div id="collapseRental" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Rental records:</h6>
            <a class="collapse-item" href="rental_index.php">Non-Return</a>
            <a class="collapse-item" href="rental_index_returned.php">Returned</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Payment management -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePayment" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-money-bill-wave"></i>
          <span>Payments Management</span>
        </a>
        <div id="collapsePayment" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Payment records:</h6>
            <a class="collapse-item" href="payment_index.php">Unpaid</a>
            <a class="collapse-item" href="payment_index_paid.php">Paid</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Inventory management -->
      <li class="nav-item">
        <a class="nav-link" href="customers_index.php">
          <i class="fas fa-fw fa-users"></i>
          <span>Customers Management</span></a>
      </li>

      <!-- Nav Item - User management -->
      <li class="nav-item">
        <a class="nav-link" href="users_index.php">
          <i class="fas fa-fw fa-user"></i>
          <span>Users Management</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
